<template>
	<div id="blocks">
    <draggable :options="{group: {'name': 'blocks', 'pull': 'clone', 'put': false}, sort: false}">
  		<imageBlock ref="imageBlock"></imageBlock>
  		<dividerBlock ref="dividerBlock"></dividerBlock>
    </draggable>
	</div>
</template>

<script>

import imageBlock from './blocks/imageBlock.vue'
import dividerBlock from './blocks/dividerBlock.vue'

import draggable from 'vuedraggable'

export default {
  name: 'contentBlocks',
  data () {
    return {
      msg: ''
    }
  },

  components: {
    imageBlock,
    dividerBlock,
    draggable
  }
}
</script>
