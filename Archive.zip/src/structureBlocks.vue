<template>
	<div id="structures">
    <draggable :options="{group: {'name': 'sections', 'pull': 'clone', 'put': false}, sort: false}">
      <div class="block" data-cols="1">Cols 1</div>
      <div class="block" data-cols="2">Cols 2</div>
      <div class="block" data-cols="3">Cols 3</div>
      <div class="block" data-cols="4">Cols 4</div>
    </draggable>
	</div>
</template>

<script>

import draggable from 'vuedraggable'

export default {
  name: 'structureBlocks',
  data () {
    return {
      msg: ''
    }
  },

  components: {
    draggable
  }
}
</script>
