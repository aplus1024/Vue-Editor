import Vue from 'vue'
import App from './App.vue'
import store from './store/store'

var vueapp = new Vue({
	store, // inject store to all children
	el: '#app',
	render: h => h(App, {email: 'testhtml'})
})