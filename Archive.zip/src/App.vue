<template>
  <div id="app">
    <div id="left">
        <structureBlocks></structureBlocks>
        <contentBlocks></contentBlocks>
      </draggable>
    </div>

    <div id="right"> 
      
      <email></email>
      
    </div>

  </div>
</template>

<script>
import { mapMutations } from 'vuex'
import structureBlocks from './structureBlocks.vue'
import contentBlocks from './contentBlocks.vue'
import email from './email.vue'

import dragula from 'dragula'

import draggable from 'vuedraggable'

export default {
  
  name: 'app',

  blocksDragula: 'dragula',

  activeBlock: null,

  activeSegment: null,

  data () {
    return {
      
    }
  },

  components: {
    structureBlocks,
    contentBlocks,
    email,
    draggable
  },

  methods: {

  },

  created: function()
  {
    /*
    var drops = [].slice.call(document.querySelectorAll('#templateContent>div div'))
      drops.push(document.getElementById('block'))

      var drake = dragula(drops, {
        copy: function (el, source) {
            return source === document.getElementById('block')
          },
          accepts: function (el, target) {
            return target !== document.getElementById('block')
          }
      });

      drake.on('drop', function(el, target, source, sibling){
      console.log(el);
      console.log(sibling);
    });
      this.$options.blocksDragula = drake
    //console.log(this.$options.blocksDragula)
    */
  },

  mounted:function()
  {
    //this.$refs.email.addSection(2)
    //this.$refs.email.addSection(3)
    //this.$refs.email.addSection(1)
    //this.$refs.email.addSection(4)
    this.$store.dispatch('addSection', {'columns': 1, 'sectionIndex': 0})

    /*
    var drake = dragula([document.getElementById('structure'), document.querySelector('#templateContent')], {
      copy: function (el, source) {
          return source === document.getElementById('structure')
        },
        accepts: function (el, target) {
          return target !== document.getElementById('structure')
        }
    });

    drake.on('drop', function(el, target, source, sibling){
      //console.log(el);
    });*/
  }
}
</script>

<style>
body, html{
  margin: 0;
  padding: 0;
  width: 100%;
}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  margin: 0;
  padding: 0;
  width: 100%;
}
#left{
  width: 300px;
  float: left;
  border-right: 1px solid black;
}
.block{
  padding: 15px;
}
.block.gu-transit{
  padding: 35px;
  border: 2px solid blue;
}
tr.active>td{
  border: 1px solid red;
}
#right{
  margin-left: 300px;
}
#templateContent{
  background-color: #efefef;
}
table>tbody>div{
  display: table;
  width: 100%;
}
@media only screen and (min-width:480px) {
  #templateContent .mj-column-per-100 {
    width: 100%!important;
  }
  #templateContent .mj-column-per-50 {
    width: 50%!important;
  }
  #templateContent .mj-column-per-30 {
    width: 33%!important;
  }
  #templateContent .mj-column-per-25 {
    width: 25%!important;
  }
}
</style>
