<template>
  <div class="block" data-block="Divider">Divider</div>
</template>

<script>
export default {
  name: 'dividerBlock',
  data () {
    return {
      msg: ''
    }
  }
}
</script>
