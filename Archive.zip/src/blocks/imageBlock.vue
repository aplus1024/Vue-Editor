<template>
  <div class="block" data-block="Image">Image</div>
</template>

<script>
export default {
  name: 'imageBlock',
  data () {
    return {
      msg: ''
    }
  }
}
</script>
