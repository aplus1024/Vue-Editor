import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
	state: {
		'definition': {'sections': []},

		'dragulaSections': null,
		'dragulaBlocks': null,

 		'selectedSection': null,
 		'selectedBlock': null
	},

	mutations: {
		  SET_SELECTED_SECTION(state, section){
			if(state.selectedBlock){
				state.selectedBlock.deselect()
			}
     		state.selectedBlock = block
   		},
   		CLEAR_SELECTED_SECTION(state){
   			if(state.selectedBlock){
				state.selectedBlock.deselect()
			}
     		state.selectedSection = null
   		},
		  SET_SELECTED_BLOCK(state, block){
			if(state.selectedBlock){
				state.selectedBlock.deselect()
			}
     		state.selectedBlock = block
   		},
   		CLEAR_SELECTED_BLOCK(state){
   			if(state.selectedBlock){
				state.selectedBlock.deselect()
			}
     		state.selectedBlock = null
   		},

   		ADD_SECTION(state, props){
     		state.definition.sections.splice(props.sectionIndex, 0, {'columns': props.columns})
   		},
   		ADD_BLOCK_TO_INDEX(state, props){
     		//state.definition.sections.push({'columns': cols});
     		state.definition.sections[props.sectionIndex].columns[props.columnIndex].blocks.splice(props.blockIndex, 0, props.block)
     		//console.log(props)
     		//console.log(state.definition.sections[section_index].columns[0])
   		},
	},

	actions: {
		setSelectedBlock({commit}, block){
			commit('SET_SELECTED_BLOCK', block)
		},
		clearSelectedBlock({commit}){
     		commit('CLEAR_SELECTED_BLOCK')
   		},

   		addSection({commit}, props){
   			var columns = [];
			for (var i = 0; i < props.columns; i++) { 
    			columns.push({
    				'blocks': [
    					{'type': 'Image', 'uuid': Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1)},
    					{'type': 'Divider', 'uuid': Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1)}
    				]
    			});
			}
     		commit('ADD_SECTION', {'columns': columns, 'sectionIndex': props.sectionIndex, 'uuid': Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1)})
   		},
   		addBlock({commit}, props){
     		console.log(props)
     		commit('ADD_BLOCK_TO_INDEX', props)
   		}
	}
})