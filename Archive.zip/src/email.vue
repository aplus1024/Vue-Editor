<template>
  <div id="templateContent">
  	<draggable @add="onAdd" :options="{group: {'name': 'sections'}, scroll: true}">
  		<mjmlSection v-for="section in definition.sections" :section="section" :cols="section.columns.length" :key="section.uuid"></mjmlSection>
  	</draggable>
  </div>
</template>

<script>

import mjmlSection from './mjml/mjmlSection.vue'

import draggable from 'vuedraggable'

export default {

	name: 'email',
	props: [],

	data () {
		return {
			definition: this.$store.state.definition
		}
  	},

	methods: {
    	onAdd: function(evt){
      		var droppedItem = evt.item
      		var colsCount = droppedItem.dataset.cols
      		droppedItem.parentNode.removeChild(droppedItem)
      		this.$store.dispatch('addSection', {'sectionIndex': evt.newIndex, 'columns': colsCount})
    	}
  	},
	
	components: {
    	mjmlSection,
    	draggable
  	}
}
</script>
