<template>
  <div v-bind:class="columnClass" style="vertical-align:top;display:inline-block;direction:ltr;font-size:13px;text-align:left;width:100%;">
    <table role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
      <tbody v-if="column.blocks.length">
        <draggable @add="onAdd" :options="{group: {'name': 'blocks'}}">
          <mjmlBlock v-for="block in column.blocks" v-bind:block="block"></mjmlBlock>
        </draggable>
      </tbody>
      <tbody v-else>
        <emptyBlock></emptyBlock>
      </tbody>
    </table>
  </div>
</template>

<script>

import mjmlBlock from './mjmlBlock.vue'
import emptyBlock from './emptyBlock.vue'

import draggable from 'vuedraggable'

export default {

  name: 'mjmlColumn',
  props: ['column', 'totalColumns'],
  
  data () {
      return {
        columnClass: {
          'outlook-group-fix': true,
          'mj-column-per-100': this.totalColumns==1,
          'mj-column-per-50': this.totalColumns==2,
          'mj-column-per-30': this.totalColumns==3,
          'mj-column-per-25': this.totalColumns==4
        }
      }
  },

  created:function()
  {
      console.log(this.totalColumns)
  },

  mounted:function()
  {
    //console.log(this.$parent.section)
    //console.log(this.$parent.$parent.$parent.$options.blocksDragula)
    //var drops = [].slice.call(document.querySelectorAll('#templateContent>div div>table>tbody'))
    //drops.push(document.getElementById('block'))
    //this.$root.$children[0].$options.blocksDragula.containers = drops
  },

  methods:{
    onAdd: function(evt){
      var droppedItem = evt.item
      var blockType = droppedItem.dataset.block
      droppedItem.parentNode.removeChild(droppedItem)
      this.$store.dispatch('addBlock', {'sectionIndex': 0, 'columnIndex': 0, 'blockIndex': 0, 'block': {'type': blockType}})
    }
  },
  
  components: {
      mjmlBlock,
      emptyBlock,
      draggable
  }
}
</script>
