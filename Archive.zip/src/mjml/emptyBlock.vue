<template>
  <tr>
      <td style="word-break:break-word;padding:10px 25px;">
      column empty
    </td>
  </tr>
</template>

<script>

export default {

  name: 'emptyBlock',
  props: [],
  
  data () {
      return {
        
      }
  },
  
  components: {
      
  }
}
</script>
