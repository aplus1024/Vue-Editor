<template>
	<tr v-on:mouseover="mouseOver" v-on:click.stop="click" v-bind:class="{ active: isActive, draggableBlock: true }">
	  	<td style="word-break:break-word;font-size:0px;padding:10px 25px;">
			<p style="font-size:1px;margin:0px auto;border-top:4px solid #F45E43;width:100%;"></p>
		</td>
	</tr>
</template>

<script>
export default {
  name: 'mjmlDivider',

  data () {
      return {
          hovered: false,
          isActive: false
      }
    },

    methods: {
        deselect: function(){
          this.isActive = false
        },
        mouseOver: function(){

        },
        click: function(){
            this.isActive = true
            this.$store.dispatch('setSelectedBlock', this)
        }
    }
}
</script>
