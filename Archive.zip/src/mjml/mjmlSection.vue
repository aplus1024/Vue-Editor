<template>
	<div v-on:mouseover="mouseOver" v-on:click="click">
		<div style="margin:0px auto;max-width:600px;">
			<table role="presentation" cellpadding="0" cellspacing="0" style="font-size:0px;width:100%;" align="center" border="0">
				<tbody>
					<tr>
						<td style="text-align:center;vertical-align:top;direction:ltr;font-size:0px;padding:20px 0px;">
							<mjmlColumn v-for="column in section.columns" v-bind:column="column" v-bind:totalColumns="cols" :key="column.uuid"></mjmlColumn>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</template>

<script>
import mjmlColumn from './mjmlColumn.vue'

export default {

	name: 'mjmlSection',
	props: ['section', 'cols'],
	
	data () {
    	return {
      		index: null
    	}
  	},
	
	components: {
    	mjmlColumn
  	},

  	created:function()
    {

    },

    methods: {
        mouseOver: function(){
            //console.log('section hover')
        },
        click: function(){
            //console.log('section click')
        }
    }
}
</script>
