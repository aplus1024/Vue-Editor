<template>
  <tr v-on:mouseover="mouseOver" v-on:click.stop="click" v-bind:class="{ active: isActive, draggableBlock: true }">
	  <td style="word-break:break-word;font-size:0px;padding:10px 25px;" align="center">
	    <table role="presentation" cellpadding="0" cellspacing="0" style="border-collapse:collapse;border-spacing:0px;" align="center" border="0">
	      <tbody>
	        <tr>
	          <td style="width:100px;"><img alt="" title="" height="auto" src="https://mjml.io/assets/img/logo-small.png" style="border:none;border-radius:;display:block;outline:none;text-decoration:none;width:100%;height:auto;" width="100"></td>
	        </tr>
	      </tbody>
	    </table>
	  </td>
	</tr>
</template>

<script>
export default {
	name: 'mjmlImage',

  props: ['block'],

	data () {
    	return {
      		hovered: false,
          isActive: false
    	}
  	},

  	methods: {
  		deselect: function(){
  			this.isActive = false
  		},
        mouseOver: function(){

        },
        click: function(){
            this.isActive = true
            this.$store.dispatch('setSelectedBlock', this)
        }
    },

    updated:function()
    {
      //console.log(this.block.url)
    }
}
</script>
