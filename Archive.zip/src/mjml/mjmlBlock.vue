<script>

import mjmlImage from './mjmlImage.vue'
import mjmlDivider from './mjmlDivider.vue'

export default {
  name: 'mjmlBlock',
  props: ['block'],
  data () {
    return {
      
    }
  },
  render: function (createElement) {
    return createElement('mjml' + this.block.type, {
      props: {
        block: this.block
      }
    })
  },
  components: {
    mjmlImage,
    mjmlDivider
  }
}
</script>
